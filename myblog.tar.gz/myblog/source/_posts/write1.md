---


title: 冬夜随感 
date: 2016-11-26
tag: 奈何情生君未知
---

<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="https://music.163.com/outchain/player?type=2&id=26145721&auto=0&height=66"></iframe>

![](write1/a.png)

多想
在冬夜的马路上
尽情的高歌一曲
<script type="text/javascript" src="./star.js" id="mymouse"></script>

这样
每吸一口气
就像吃了一口冰糕
<!--more-->
而呼出的热气
是自制的特效
睫毛上凝结的霜花
是最圣洁的妆

配合着节奏
和凛冽的
冻得硬邦邦的梦想

倘若
你因我的歌声
放慢了忙碌的脚步

那么我会
踏着吱吱的初雪
为你献上一支

蹩脚的
载满诚意的舞

